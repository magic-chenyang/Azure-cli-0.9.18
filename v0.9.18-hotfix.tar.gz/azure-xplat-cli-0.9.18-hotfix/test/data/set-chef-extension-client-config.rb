log_level        :info
log_location     "c:/chef/logs"
chef_server_url  "https://api.opscode.com/organizations/orgname"
validation_client_name 	"orgname-validator"