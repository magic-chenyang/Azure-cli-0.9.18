function insert(item, user, request) {
    console.log('Sample information');
    console.log('Invoking insert script');
    console.error('Sample error');
    request.execute();
}