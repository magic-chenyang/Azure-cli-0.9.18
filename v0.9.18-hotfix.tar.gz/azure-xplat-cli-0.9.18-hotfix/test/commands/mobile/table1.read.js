function read(id, user, request) {
        console.log('Invoking read script');        
	request.respond();
}
